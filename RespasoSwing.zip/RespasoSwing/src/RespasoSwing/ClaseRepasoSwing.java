package RespasoSwing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;


public class ClaseRepasoSwing {

	public static void main(String[] args) {

		MarcoRepaso miMarco = new MarcoRepaso();

		miMarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}


class MarcoRepaso extends JFrame

{

	public MarcoRepaso()

	{

		setSize(600,600);
		setTitle("Formulario de Reservas - Adri�n Juzgado");
		LaminaRepaso miLamina = new LaminaRepaso();
		add(miLamina);
		setVisible(true);
			

	}

}


class LaminaRepaso extends JPanel{

	JLabel tltFormulario =new JLabel("            ************** HOTEL LOVING JAVA **************");
	BorderLayout disposicion = new BorderLayout();
	
	//declaramos todos los campos
	private JComboBox comboPersonas;
	private JTextArea txtAreaComentarios;
	private JLabel textFieldnombre;
	private JLabel textFieldapellidos;
	private JTextField name;
	private JTextField surname;
	private JButton btnReservar;
	private JButton btnBorrar;
	private JSpinner miSpinnerFecha;
	private JLabel comentarios;
	private SpinnerModel sm;
	private ButtonGroup grpHabitaciones ;
	private JSpinner spinnerNoches ;
	
	//variables Radio Button
	private ButtonGroup grpR�gimen;
	private JRadioButton pensi�n;
	//lectura y escritura
	private FileWriter fw;
	private PrintWriter pw;	
	
	private String room="Doble";
	private String alimentacion="M. Pensi�n";
	private int personas;
	//precio Total
	private int precioTotal;	
	
	//menus
	private JMenuItem habSimple;
	private JMenuItem habDobles;
	private JMenuItem suite;
	private JMenuItem presidencial;
	private JMenuItem menuRestaurante;
	private JMenuItem menuGimnasio;
	private JMenuItem menuPiscina;
	
	private boolean hacerReserva=false;
	private boolean hacerReserva2=false;
	
	public LaminaRepaso() {
		

		
		//creamos los Menus
		JMenuBar barraMenu=new JMenuBar();
		JMenu menuHabitaciones=new JMenu("Habitaciones");
		JMenu menuServicios=new JMenu("Servicios");
		
		//items habitaciones
		habSimple=new JMenuItem("Habitaci�n Simple");
		OyenteMenu oyenteMenu=new OyenteMenu();
		habSimple.addActionListener(oyenteMenu);
		
		habDobles=new JMenuItem("Habitaci�n Doble");
		habDobles.addActionListener(oyenteMenu);
		JMenu subMenu=new JMenu("Habitaci�n Superior");

		
		suite=new JMenuItem("Suite");
		suite.addActionListener(oyenteMenu);
		presidencial=new JMenuItem("Presidencial");
		presidencial.addActionListener(oyenteMenu);
		subMenu.add(suite);
		subMenu.add(presidencial);
		
		menuHabitaciones.add(habSimple);
		menuHabitaciones.add(habDobles);
		menuHabitaciones.add(subMenu);
		
		//items servicios
		menuRestaurante=new JMenuItem("Restaurante");
		menuRestaurante.addActionListener(oyenteMenu);
		menuGimnasio=new JMenuItem("Gimnasio");
		menuGimnasio.addActionListener(oyenteMenu);
		menuPiscina=new JMenuItem("Piscina");
		menuPiscina.addActionListener(oyenteMenu);

		//a�adimos los items
		menuServicios.add(menuRestaurante);
		
		//a�adimos un separador
		menuServicios.addSeparator();
		menuServicios.add(menuGimnasio);
		//a�adimos un separador
		menuServicios.addSeparator();
		menuServicios.add(menuPiscina);
		
		barraMenu.add(menuHabitaciones);
		barraMenu.add(menuServicios);
		
		
		
		//---------------------
		
		//le damos la disposicion al proyecto
		setLayout(disposicion);
		
		//Panel Norte
		JPanel pnlNorte=new JPanel();
		BorderLayout disposicionNorte=new BorderLayout();
		pnlNorte.setLayout(disposicionNorte);
		pnlNorte.add(barraMenu);

		//Damos la fuente al titulo
		Font font = new Font("Copperplate", Font.BOLD, 20);
		tltFormulario.setFont(font);
		pnlNorte.add(tltFormulario, BorderLayout.SOUTH);
		//panel Central
		JPanel pnlCentral=new JPanel();
		FlowLayout lytCentral=new FlowLayout();
		pnlCentral.setLayout(lytCentral);

		//Nombre
		textFieldnombre =new JLabel("Nombre: ");
		textFieldnombre.setPreferredSize(new Dimension(80, 40));
		name = new JTextField(40); 
		
		//instanciamos la clase Oyente
		OyenteTexto miEvento = new OyenteTexto();
		name.addKeyListener(miEvento);
		pnlCentral.add(textFieldnombre);
		pnlCentral.add(name);
		
		//Apellidos
		textFieldapellidos =new JLabel("Apellidos: ");
		textFieldapellidos.setPreferredSize(new Dimension(80, 40));
		surname = new JTextField(40); 
		surname.addKeyListener(miEvento);
		pnlCentral.add(textFieldapellidos);
		pnlCentral.add(surname);
		
		//Fecha Entrada
		JLabel fecha =new JLabel("Fecha Entrada: ");
		fecha.setPreferredSize(new Dimension(120,40));
		miSpinnerFecha =new JSpinner(new SpinnerDateModel());
		miSpinnerFecha.setPreferredSize(new Dimension(120, 20));

		pnlCentral.add(fecha);
		pnlCentral.add(miSpinnerFecha);
		
		//Noches
		JLabel noches =new JLabel("Noches: ");
		
		//Le damos los limites al spinner de las noches
		sm = new SpinnerNumberModel(1, 1, 30, 1); 
		 spinnerNoches= new JSpinner(sm);
		 spinnerNoches.setPreferredSize(new Dimension(120, 20));
		pnlCentral.add(noches);

		pnlCentral.add(spinnerNoches);
		
		//Personas
		JLabel personas =new JLabel("Personas: ");
		comboPersonas=new JComboBox();
		comboPersonas.addItem(1);
		comboPersonas.addItem(2);
		comboPersonas.addItem(3);
		comboPersonas.addItem(4);		
		
		OyentePersonas oyentePersonas=new OyentePersonas();
		comboPersonas.addActionListener(oyentePersonas);
	

		pnlCentral.add(personas);
		pnlCentral.add(comboPersonas);
		
		
		//Habitaciones
		//cremos un grupo para los radiobuttons
				grpHabitaciones= new ButtonGroup();
				JLabel habitaciones =new JLabel("Habitaciones: ");
				habitaciones.setPreferredSize(new Dimension(230, 40));
				
				//creamos 3 radio buttons
				JRadioButton simple = new JRadioButton("Simple", false);
				JRadioButton habDoble = new JRadioButton("Doble", true);
				JRadioButton habSuite = new JRadioButton("Suite", false);
				JRadioButton habPresidencial = new JRadioButton("Presidencial", false);

				//agregamos los botones al grupo
				grpHabitaciones.add(simple);
				grpHabitaciones.add(habDoble);
				grpHabitaciones.add(habSuite);
				grpHabitaciones.add(habPresidencial);
				
				//agregamos los botones
				JPanel pnlBotones = new JPanel();
				pnlBotones.add(simple);
				pnlBotones.add(habDoble);
				pnlBotones.add(habSuite);
				pnlBotones.add(habPresidencial);
				pnlCentral.add(habitaciones);
				pnlCentral.add(pnlBotones);
				
				//instanciamos la calse oyente y le damos los eventos a cada uno de los Radio Button
				OyenteHabitacion miEventoHabitacion=new OyenteHabitacion();
				simple.addActionListener(miEventoHabitacion);
				habDoble.addActionListener(miEventoHabitacion);
				habSuite.addActionListener(miEventoHabitacion);
				habPresidencial.addActionListener(miEventoHabitacion);
				
				//Regiemn
				//cremos un grupo para los radiobuttons		
				grpR�gimen= new ButtonGroup();
				JLabel regimen =new JLabel("R�gimen: ");
				regimen.setPreferredSize(new Dimension(120, 40));

				//creamos 3 radio buttons
				JRadioButton alojamiento = new JRadioButton("Solo Alojamiento", false);
				JRadioButton desayuno = new JRadioButton("Desayuno", false);
				 pensi�n = new JRadioButton("M. Pensi�n", true);
				JRadioButton completa = new JRadioButton("P. Completa", false);
						
				//agregamos los botones al grupo
				grpR�gimen.add(alojamiento);
				grpR�gimen.add(desayuno);
				grpR�gimen.add(pensi�n);
				grpR�gimen.add(completa);
				
				//agregamos los botones
				JPanel pnlBotones2 = new JPanel();
				pnlBotones2.add(alojamiento);
				pnlBotones2.add(desayuno);
				pnlBotones2.add(pensi�n);
				pnlBotones2.add(completa);
				pnlCentral.add(regimen);
				pnlCentral.add(pnlBotones2);
				
				//instanciamos la calse oyente y le damos los eventos a cada uno de los Radio Button
				OyenteRegimen miEventoRegimen=new OyenteRegimen();
				alojamiento.addActionListener(miEventoRegimen);
				desayuno.addActionListener(miEventoRegimen);
				pensi�n.addActionListener(miEventoRegimen);
				completa.addActionListener(miEventoRegimen);
		
				
		//Comentarios
				comentarios =new JLabel("Comentarios: ");
				txtAreaComentarios=new JTextArea(10,48);
				//le a�adimos el salto de linea automaticamente
				txtAreaComentarios.setLineWrap(true);
				//barra de desplazamiento en caso de que sea necesario
				JScrollPane scroll = new JScrollPane (txtAreaComentarios);
				 scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				comentarios.setPreferredSize(new Dimension(535, 40));
				pnlCentral.add(comentarios);
				pnlCentral.add(scroll);


				
		//Panel SUR
		JPanel pnlSur=new JPanel();
		GridLayout lytSur=new GridLayout(1,2);
		pnlSur.setLayout(lytSur);
		 btnReservar=new JButton("Reservar");
		btnBorrar=new JButton("Borrar Datos");
		pnlSur.add(btnReservar);
		pnlSur.add(btnBorrar);
		
		//Evento Bot�n Reserva
		OyenteReserva miEventoReserva=new OyenteReserva();
		btnReservar.addActionListener(miEventoReserva);
		
		//Evento Bot�n Borrado
		OyenteBorrado miEventoBorrar =new OyenteBorrado();
		btnBorrar.addActionListener(miEventoBorrar);

		add(pnlNorte, BorderLayout.NORTH);
		add(pnlCentral, BorderLayout.CENTER);
		add(pnlSur, BorderLayout.SOUTH);
		
	}

	
	//creamos una clase interna que estar� a la escucha
		private class OyenteTexto implements KeyListener
		{

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void keyReleased(KeyEvent e) {
							
			}

			@Override
			public void keyTyped(KeyEvent e) {
				String longitudName = name.getText();
				String longitudSurname = surname.getText();

				//campos obligatorios del Nombre
				if(longitudName.length()<=3 ) {
					name.setBackground(Color.red);
					hacerReserva=false;

				}
				if(longitudName.length()>3){
					name.setBackground(Color.white);
					hacerReserva=true;

				}	
				
				//campos obligatorios del apellido

				if(longitudSurname.length()<=3 ) {
					surname.setBackground(Color.red);
					hacerReserva2=false;

				}
				if(longitudSurname.length()>3){
					surname.setBackground(Color.white);
					hacerReserva2=true;


				}
			}

		

		}
		
		//metodo para borrar todos los campos del formulario
	private class OyenteBorrado implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(e.getSource()==btnBorrar) {
				name.setText("");
				surname.setText("");
				txtAreaComentarios.setText("");
				spinnerNoches.setValue(1);
				comboPersonas.setSelectedIndex(0);
				grpR�gimen.clearSelection();
				grpHabitaciones.clearSelection();
			}		
		}	
	}
	
	
	private class OyenteReserva implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			//En esta parte calculamos el precio dependiendo de las caracteristicas que haya escogido el usuario
			int nigths=(int) spinnerNoches.getValue();
			int numPersonas=(int) comboPersonas.getSelectedItem();
			
			int importeAIncrementar=0;
			
			if(alimentacion=="Desayuno") {
				importeAIncrementar=15*nigths*(numPersonas);
			}else if(alimentacion=="M. Pensi�n") {
				importeAIncrementar=30*nigths*(numPersonas);

			}else if(alimentacion=="P. Completa") {
				importeAIncrementar=50*nigths*(numPersonas);

			}

			if(hacerReserva==true && hacerReserva2==true) {
				
			if(room=="Simple") {
				precioTotal=70*nigths+(importeAIncrementar);
				
			}else if(room=="Doble"){
				precioTotal=90*nigths+(importeAIncrementar);

			}else if(room=="Suite") {
				precioTotal=150*nigths+(importeAIncrementar);

			}else {
				precioTotal=250*nigths+(importeAIncrementar);

			}
				
			JOptionPane.showMessageDialog(null,"Reserva Realizada ");
			String nombre=name.getText().trim();
			String apellidos=surname.getText().trim();
			

			if(e.getSource()==btnReservar) {
				try {
					fw = new FileWriter("./src/RespasoSwing/Reservas/Juzgado-Adri�nReserva.txt");
					pw = new PrintWriter(fw);
					pw.write("***************DETALLES DE LA RESERVA************"+"\n"+"\n"+"Nombre: "+nombre +"\n"+"Apellidos: "+apellidos+"\n"+"Habitaci�n: "+room+ "\n"+"Fecha de Entrada: "+miSpinnerFecha.getValue()
					+"\n"+"N� Noches: "+spinnerNoches.getValue()+"\n"+"N� Personas: "+comboPersonas.getSelectedItem()+"\n"+"\n"+"Comentarios: "+txtAreaComentarios.getText()+"\n"+"\n"+"PRECIO TOTAL: "+precioTotal+"�"+"\n"+"\n"+"********************************************************");
					pw.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					
			}
			
			}else {
				JOptionPane.showMessageDialog(null,"�Asegurese de rellenar el formulario correctamente!");

			}
		}			
		}
	
	private class OyenteHabitacion implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			switch(e.getActionCommand())
			{
			case "Simple":
				room="Simple";
				break;
			case "Suite":
				room="Suite";
				break;
			case "Presidencial":
				room="Presidencial";
				break;
			}
		}		
		}
	
	
	private class OyenteRegimen implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			switch(e.getActionCommand())
			{
			case "Solo Alojamiento":
				alimentacion="Solo Alojamiento";
				break;
			case "Desayuno":
				alimentacion="Desayuno";
				break;
			case "P. Completa":
				alimentacion="P. Completa";
				break;
			}
		}		
		}
	
	private class OyentePersonas implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			switch(e.getActionCommand())
			{
			case "1":
				personas=1;
				break;
			case "2":
				personas=2;
				break;
			case "3":
				personas=3;
				break;
			case "4":
				personas=4;
				break;
			}
			}			
		}
		
	
	private class OyenteMenu implements ActionListener{
		
		//frames
		private JFrame frameSimple;
		private JFrame frameDoble;
		private JFrame frameSuite;
		private JFrame framePresidencial;
		private JFrame frameRestaurante;
		private JFrame frameGimnasio;
		private JFrame framePiscina;
		
		//paneles
		private JPanel pnlSimple;
		private JPanel pnlDoble;
		private JPanel pnlSuite;
		private JPanel pnlPresidencial;
		private JPanel pnlRestaurante;
		private JPanel pnlGimnasio;
		private JPanel pnlPiscina;

		//imagenes
		private JLabel imagenSimple =new JLabel();
		private JLabel imagenDoble;
		private JLabel imagenSuite;
		private JLabel imagenPresidencial;
		private JLabel imagenRestaurante;
		private JLabel imagenGimnasio;
		private JLabel imagenPiscina;
		
		//textAreas
		private JTextArea textAreaSimple ;
		private JTextArea textAreaDoble ;
		private JTextArea textAreaSuite ;
		private JTextArea textAreaPresidencial ;
		private JTextArea textAreaRestaurante ;
		private JTextArea textAreaGym ;
		private JTextArea textAreaSpa;



		@Override
		public void actionPerformed(ActionEvent e) {

			if(e.getSource() == habSimple){
				
				//creamos el Frame
				frameSimple=new JFrame();
				frameSimple.setSize(550,600);
				frameSimple.setTitle("Habitaci�n Simple");
				frameSimple.setVisible(true);	
				
				//declaramos el panel y la imagen
				pnlSimple=new JPanel();
				imagenSimple.setIcon(new ImageIcon("./img/simple.jpg"));

				//le damos la dimension especifica a la imagen
				Dimension size = new Dimension(650, 350);
				imagenSimple.setSize(size);
				imagenSimple.setPreferredSize(size);
				pnlSimple.add(imagenSimple);

				//a�adimos el panel al frame
				frameSimple.add(pnlSimple);
				
				//creamos el TextArea
				textAreaSimple= new JTextArea(
					    "Superficie de la habitaci�n: 20 metros\n " +
					    "Ducha\n" +
					    "Toallas\n " +
					    "Secador de  pelo \n"+
					    "TV\n " +    "Politica de humo: no se puede fumar\n"
					);
				
				textAreaSimple.setEditable(false);
				textAreaSimple.setPreferredSize(new Dimension(520,150));
				textAreaSimple.setLineWrap(true);
				pnlSimple.add(textAreaSimple);
				
				textAreaSimple.setVisible(false);

				//creamos la clase oyente que estar� a la escucha del doble clic para mostrar el TextArea
				OyenteImagenes oyente=new OyenteImagenes();
				imagenSimple.addMouseListener(oyente);

				
		
				
			}
			if(e.getSource() == habDobles){
				frameDoble=new JFrame();
				frameDoble.setSize(550,600);
				frameDoble.setTitle("Habitaci�n Doble");
				frameDoble.setVisible(true);	
				
				//declaramos el panel y la imagen
				pnlDoble=new JPanel();
				imagenDoble=new JLabel();
		          
				//le damos la dimension especifica a la imagen
				Dimension sizeDoble = new Dimension(550, 350);
				imagenDoble.setIcon(new ImageIcon("./img/doble.jpg"));
				imagenDoble.setSize(sizeDoble);
				imagenDoble.setPreferredSize(sizeDoble);
				pnlDoble.add(imagenDoble);
				
				//a�adimos el panel al frame
				frameDoble.add(pnlDoble);

				
				//creamos el TextArea

				textAreaDoble= new JTextArea(
					    
					     "Superficie de la habitacion: 30 m\n " +
					    "Ducha\n" +
					    "Toallas y albornoces\n " +
					    "Secador de  pelo \n"+
					    "TV LED\n " +    "Dos camas dobles\n"
					);
				
				textAreaDoble.setEditable(false);
				textAreaDoble.setPreferredSize(new Dimension(520,130));
				textAreaDoble.setLineWrap(true);
				pnlDoble.add(textAreaDoble);
				
				textAreaDoble.setVisible(false);
				
				//creamos la clase oyente que estar� a la escucha del doble clic para mostrar el TextArea
				OyenteImagenes oyente=new OyenteImagenes();
				imagenDoble.addMouseListener(oyente);
				
				
			

				
			
				
			}
			if(e.getSource() == suite){
				frameSuite=new JFrame();
				frameSuite.setSize(550,600);
				frameSuite.setTitle("Suite");
				frameSuite.setVisible(true);	
				
				
				//declaramos el panel y la imagen
				pnlSuite=new JPanel();
				imagenSuite=new JLabel();
				
				
				//le damos la dimension especifica a la imagen
				Dimension sizeSuite = new Dimension(550, 350);
				imagenSuite.setIcon(new ImageIcon("./img/suite.jpg"));
				imagenSuite.setSize(sizeSuite);
				imagenSuite.setPreferredSize(sizeSuite);
				pnlSuite.add(imagenSuite);
				
		
				//a�adimos el panel al frame
				frameSuite.add(pnlSuite);
				
				//creamos el TextArea
				textAreaSuite= new JTextArea(
					    
					     "Superficie de la habitacion: 50 metros\n " +
					    "Banera hidromasaje\n" +
					    "Todo tipo de amenities\n " +
					    "Caja fuerte \n"+
					    "Terraza vistas mar\n " +    "Cama King Size\n"
					);
				
				textAreaSuite.setEditable(false);
				textAreaSuite.setPreferredSize(new Dimension(520,130));
				textAreaSuite.setLineWrap(true);
				pnlSuite.add(textAreaSuite);
				
				textAreaSuite.setVisible(false);
				
				//creamos la clase oyente que estar� a la escucha del doble clic para mostrar el TextArea
				OyenteImagenes oyente=new OyenteImagenes();
				imagenSuite.addMouseListener(oyente);
				

		
			}
			
			if(e.getSource() == presidencial){
				framePresidencial=new JFrame();
				framePresidencial.setSize(550,600);
				framePresidencial.setTitle("Habitaci�n Presidencial");
				framePresidencial.setVisible(true);		
				
				//declaramos el panel y la imagen
				pnlPresidencial=new JPanel();
				imagenPresidencial=new JLabel();
				
				
				//le damos la dimension especifica a la imagen
				Dimension sizePresidencial = new Dimension(550, 350);
				imagenPresidencial.setIcon(new ImageIcon("./img/presidencial.jpg"));
				imagenPresidencial.setSize(sizePresidencial);
				imagenPresidencial.setPreferredSize(sizePresidencial);
				pnlPresidencial.add(imagenPresidencial);
				
				
				//a�adimos el panel al frame
				framePresidencial.add(pnlPresidencial);
				
				
				
				//creamos el TextArea
				textAreaPresidencial= new JTextArea(
					    
					     "Superficie de la habitacion: 90 metros\n " +
					    "SPA privado\n" +
					    "Servicio de habitacion personal\n " +
					    "Jardin privado con piscin\n"+
					    "HomeCinema\n " +    "Cama King Size\n"
					);
				
				textAreaPresidencial.setEditable(false);
				textAreaPresidencial.setPreferredSize(new Dimension(520,130));
				textAreaPresidencial.setLineWrap(true);
				pnlPresidencial.add(textAreaPresidencial);
				
				textAreaPresidencial.setVisible(false);
				
				
				//creamos la clase oyente que estar� a la escucha del doble clic para mostrar el TextArea
				OyenteImagenes oyente=new OyenteImagenes();
				imagenPresidencial.addMouseListener(oyente);
				
				
			}
			
			if(e.getSource() == menuRestaurante){
				frameRestaurante=new JFrame();
				frameRestaurante.setSize(550,600);
				frameRestaurante.setTitle("Restaurante");
				frameRestaurante.setVisible(true);	
				
				
				//declaramos el panel y la imagen
				pnlRestaurante=new JPanel();
				imagenRestaurante=new JLabel();
				
				
				//le damos la dimension especifica a la imagen
				Dimension sizeRestaurante = new Dimension(550, 350);
				imagenRestaurante.setIcon(new ImageIcon("./img/restaurante.jpg"));
				imagenRestaurante.setSize(sizeRestaurante);
				imagenRestaurante.setPreferredSize(sizeRestaurante);
				pnlRestaurante.add(imagenRestaurante);
				
				
				//a�adimos el panel al frame
				frameRestaurante.add(pnlRestaurante);
				
				
				//creamos el TextArea
				textAreaRestaurante= new JTextArea(
					    
					     "El ambiente informal y acogedor de nuestro restaurante esta decorado con un estilo mediterraneo moderno. Pruebe una especialidad local"
					     + " o internacional acompa�ado de un te JING o de un vino fino. La tranquila terraza es ideal para realizar eventos sociales y fiestas con cocteles.\n " 

					);
				
				textAreaRestaurante.setEditable(false);
				textAreaRestaurante.setPreferredSize(new Dimension(520,100));
				textAreaRestaurante.setLineWrap(true);
				pnlRestaurante.add(textAreaRestaurante);
				
				textAreaRestaurante.setVisible(false);
				
				//creamos la clase oyente que estar� a la escucha del doble clic para mostrar el TextArea
				OyenteImagenes oyente=new OyenteImagenes();
				imagenRestaurante.addMouseListener(oyente);
				
				
				
			}
			
			
			if(e.getSource() == menuGimnasio){
				frameGimnasio=new JFrame();
				frameGimnasio.setSize(550,600);
				frameGimnasio.setTitle("Gimnasio");
				frameGimnasio.setVisible(true);	
				
				
				//declaramos el panel y la imagen
				pnlGimnasio=new JPanel();
				imagenGimnasio=new JLabel();
				
				
				//le damos la dimension especifica a la imagen
				Dimension sizeGimnasio = new Dimension(550, 350);
				imagenGimnasio.setIcon(new ImageIcon("./img/gym.jpg"));
				imagenGimnasio.setSize(sizeGimnasio);
				imagenGimnasio.setPreferredSize(sizeGimnasio);
				pnlGimnasio.add(imagenGimnasio);
				
				
				
				//a�adimos el panel al frame
				frameGimnasio.add(pnlGimnasio);
				
				
				//creamos el TextArea
				textAreaGym= new JTextArea(
					    
					     "El gimnasio del hotel Loving Java pone a su disposicion todas sus maquinas de ultima generacion:\n " +
					    "Cintas de correr\n" +
					    "Elipticas\n " +
					    "Bicicletas estaticas\n"+
					    "Piscina climatizada\n " +    "Maquinas de musculacion.\n"
					);
				
				textAreaGym.setEditable(false);
				textAreaGym.setPreferredSize(new Dimension(520,150));
				textAreaGym.setLineWrap(true);
				pnlGimnasio.add(textAreaGym);
				
				textAreaGym.setVisible(false);
				
				//creamos la clase oyente que estar� a la escucha del doble clic para mostrar el TextArea
				OyenteImagenes oyente=new OyenteImagenes();
				imagenGimnasio.addMouseListener(oyente);
				
			}
			
			
			if(e.getSource() == menuPiscina){
				framePiscina=new JFrame();
				framePiscina.setSize(550,600);
				framePiscina.setTitle("Piscina");
				framePiscina.setVisible(true);	
				
				
				
				//declaramos el panel y la imagen
				pnlPiscina=new JPanel();
				imagenPiscina=new JLabel();
				
				
				//le damos la dimension especifica a la imagen
				Dimension sizePiscina = new Dimension(550, 350);
				imagenPiscina.setIcon(new ImageIcon("./img/spa.jpg"));
				imagenPiscina.setSize(sizePiscina);
				imagenPiscina.setPreferredSize(sizePiscina);
				pnlPiscina.add(imagenPiscina);
				
				
				
				//a�adimos el panel al frame
				framePiscina.add(pnlPiscina);
				
				
				//creamos el TextArea
				textAreaSpa= new JTextArea(
					    
					     "El gimnasio del hotel Loving Java pone a su disposicion todas sus maquinas de ultima generacion:\n " +
					    "Cintas de correr\n" +
					    "Elipticas\n " +
					    "Bicicletas estaticas\n"+
					    "Piscina climatizada\n " +    "Maquinas de musculaci�n.\n"
					);
				
				textAreaSpa.setEditable(false);
				textAreaSpa.setPreferredSize(new Dimension(520,130));
				textAreaSpa.setLineWrap(true);
				pnlPiscina.add(textAreaSpa);
				
		
				textAreaSpa.setVisible(false);
				
				//creamos la clase oyente que estar� a la escucha del doble clic para mostrar el TextArea
				OyenteImagenes oyente=new OyenteImagenes();
				imagenPiscina.addMouseListener(oyente);
				
				
			}
		}
		
		
		private class OyenteImagenes extends MouseAdapter{

			public void mouseClicked(MouseEvent e) {
				
			    if (e.getClickCount() == 2 && e.getSource()==imagenSimple) {
			    	
			    
					textAreaSimple.setVisible(true);

			    	
			    } else if (e.getClickCount() == 2 && e.getSource()==imagenDoble) {	    	
			    	
					textAreaDoble.setVisible(true);

			    }else if (e.getClickCount() == 2 && e.getSource()==imagenSuite) {
			    	
					textAreaSuite.setVisible(true);

			    }else if (e.getClickCount() == 2 && e.getSource()==imagenPresidencial) {
			    	
					textAreaPresidencial.setVisible(true);

			    	
			    }else if (e.getClickCount() == 2 && e.getSource()==imagenRestaurante) {
					textAreaRestaurante.setVisible(true);

			    }else if (e.getClickCount() == 2 && e.getSource()==imagenGimnasio) {
					textAreaGym.setVisible(true);

			    }else if (e.getClickCount() == 2 && e.getSource()==imagenPiscina) {
					textAreaSpa.setVisible(true);

			    }
			}
			
		}

			
	}
	
	

	
	
}


