module.exports = {
  mongodb: {
    URI: 'mongodb://localhost:27017/login-node'
  }
};
